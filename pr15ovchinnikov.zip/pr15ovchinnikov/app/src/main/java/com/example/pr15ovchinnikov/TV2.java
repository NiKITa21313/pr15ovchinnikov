package com.example.pr15ovchinnikov;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class TV2 extends AppCompatActivity implements View.OnClickListener{
ImageView iv1, iv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tv2);
        iv1 = findViewById(R.id.imageView8);
        iv2 = findViewById(R.id.imageView13);
        iv1.setOnClickListener(this);
        iv2.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.imageView8:
                startActivity(new Intent(this, TV3.class));
                break;
            case R.id.imageView13:
                startActivity(new Intent(this, TV3.class));
                break;
        }
    }
}